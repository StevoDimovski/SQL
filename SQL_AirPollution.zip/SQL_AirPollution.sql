--select * from [AirPollution]
--# Question 1
-- What location in Skopje has the highest average pollution for each of the pollutants? .......... (2 points)
drop table  #Result
;with cte as
(
select 
pollutant,
round(AVG([Centar]),2) CentarAverage , 
round(AVG([GaziBaba]),2) GaziBabaAverage , 
round(AVG([Karpos]),2) KarposAverage ,
round(AVG([Lisice]),2) LisiceAverage, 
round(AVG([Miladinovci]),2) MiladinovciAverage,
round(AVG([Mobile]),2) MobileAverage,
round(AVG([Rektorat]),2) RektoratAverage
from [dbo].[AirPollution]
group by pollutant
)
select
pollutant, NameOfLocation, value
into #Result
from cte unpivot (
value for NameOfLocation in (CentarAverage,GaziBabaAverage,KarposAverage,LisiceAverage,MiladinovciAverage,MobileAverage,RektoratAverage)
) as U

;with final as
(
  select *,
  ROW_NUMBER() OVER (PARTITION BY pollutant order by value desc) rn
  from #Result
)

select pollutant,NameOFLocation,value
from final
where rn=1

--# Question 2
-- For every year, for each of the pollutants, on what time stamp is the maximum pollution for every location? 


drop table #Centar

;WITH Centar as
(
select 
round(Centar,2) Centar,Time,pollutant,YEAR(Time) as year,month(time) as month,
ROW_NUMBER() OVER ( PARTITION BY POllutant,YEAR(time) order by Centar desc) RN
from AirPollution
)

select * 
into #Centar
from Centar where RN=1

select Pollutant,year,month,Time from #Centar
order by 1,2


-- What time of the year seems to have the most pollution in Skopje? .......... (2 points)

drop table #Centar_1
select pollutant,month,count(month) over(partition by month) as MonthCount
into #Centar_1
from #Centar
order by MonthCount desc
;with cte as 
(
select *,
ROW_NUMBER() OVER (PARTITION BY pollutant order by MonthCount desc) RN
from #Centar_1
)

select Pollutant,Month from cte 
where RN=1

--# Question 3
--In what month of the year is the average polution accross locations highest for each of the pollutants? .......... (2 points)

--1) Centar
;with Centar as
(
select 
pollutant,
month,
avg(value) as AveragePollution,
ROW_NUMBER() OVER (PARTITION BY Pollutant order by avg(value) desc ) as RN
	from [dbo].[Centar]
	group by pollutant,month
	--order by 1,3 desc
)
select * 
from Centar
where RN=1
------------------------------------------------------------------------------------------------------------------------------------------
--2) GaziBaba
;with GaziBaba as
(
select 
pollutant,
month,
avg(value) as AveragePollution,
ROW_NUMBER() OVER (PARTITION BY Pollutant order by avg(value) desc ) as RN
	from [dbo].[GaziBaba]
	group by pollutant,month
	--order by 1,3 desc
)
select * 
from GaziBaba
where RN=1
----------------------------------------------------------------------------------------------
-- 3) Karpos
;with Karpos as
(
select 
pollutant,
month,
avg(value) as AveragePollution,
ROW_NUMBER() OVER (PARTITION BY Pollutant order by avg(value) desc ) as RN
	from [dbo].[Karpos]
	group by pollutant,month
	--order by 1,3 desc
)
select * 
from Karpos
where RN=1

/********************************************************************************************/

-- 4) Lisice
;with Lisice as
(
select 
pollutant,
month,
avg(value) as AveragePollution,
ROW_NUMBER() OVER (PARTITION BY Pollutant order by avg(value) desc ) as RN
	from [dbo].[Lisice]
	group by pollutant,month
	--order by 1,3 desc
)
select * 
from Lisice
where RN=1

/********************************************************************************************/

-- 5) Miladinovci
;with Miladinovci as
(
select 
pollutant,
month,
avg(value) as AveragePollution,
ROW_NUMBER() OVER (PARTITION BY Pollutant order by avg(value) desc ) as RN
	from [dbo].[Miladinovci]
	group by pollutant,month
	--order by 1,3 desc
)
select * 
from Miladinovci
where RN=1

/********************************************************************************************/

-- 6) Mobile
;with Mobile as
(
select 
pollutant,
month,
avg(value) as AveragePollution,
ROW_NUMBER() OVER (PARTITION BY Pollutant order by avg(value) desc ) as RN
	from [dbo].[Mobile]
	group by pollutant,month
	--order by 1,3 desc
)
select * 
from Mobile
where RN=1

/********************************************************************************************/

-- 7) Rektorat
;with Rektorat as
(
select 
pollutant,
month,
avg(value) as AveragePollution,
ROW_NUMBER() OVER (PARTITION BY Pollutant order by avg(value) desc ) as RN
	from [dbo].[Rektorat]
	group by pollutant,month
	--order by 1,3 desc
)
select * 
from Rektorat
where RN=1


/*## Questions 6
If the range of values for PM10 considered safe and unsafe is according to the following scale:

Good                                    0-50

Moderate 	                            51-154

Unhealthy for sensitive individuals 	155-254

Unhealthy 	                            255-354

Very unhealthy                          355-424

Hazardous                               425-504

On how many days in each year, was the average value of PM10 meauserd accross locations worse than moderate?  .......... (3 points)*/



/********************************************************  Centar **********************************************************************/
;with PM10 as
(
select pollutant,year,month,day,AVG(Value) as AverageValue
--distinct Year,count(day)
from [dbo].[Centar]
where Pollutant='PM10'
group by pollutant,year,month,day
having (AVG(Value) > 154)
)

select year,count(AverageValue) as NumberOfDays
from PM10
group by year


/********************************************************  GaziBaba **********************************************************************/
;with PM10 as
(
select pollutant,year,month,day,AVG(Value) as AverageValue
--distinct Year,count(day)
from [dbo].[GaziBaba]
where Pollutant='PM10'
group by pollutant,year,month,day
having (AVG(Value) > 154)
)

select year,count(AverageValue) as NumberOfDays
from PM10
group by year

/********************************************************  Karpos **********************************************************************/
;with PM10 as
(
select pollutant,year,month,day,AVG(Value) as AverageValue
--distinct Year,count(day)
from [dbo].[Karpos]
where Pollutant='PM10'
group by pollutant,year,month,day
having (AVG(Value) > 154)
)

select year,count(AverageValue) as NumberOfDays
from PM10
group by year

/********************************************************  Lisice **********************************************************************/
;with PM10 as
(
select pollutant,year,month,day,AVG(Value) as AverageValue
--distinct Year,count(day)
from [dbo].Lisice
where Pollutant='PM10'
group by pollutant,year,month,day
having (AVG(Value) > 154)
)

select year,count(AverageValue) as NumberOfDays
from PM10
group by year

/********************************************************  Miladinovci **********************************************************************/
;with PM10 as
(
select pollutant,year,month,day,AVG(Value) as AverageValue
--distinct Year,count(day)
from [dbo].Miladinovci
where Pollutant='PM10'
group by pollutant,year,month,day
having (AVG(Value) > 154)
)

select year,count(AverageValue) as NumberOfDays
from PM10
group by year

/********************************************************  Mobile **********************************************************************/
;with PM10 as
(
select pollutant,year,month,day,AVG(Value) as AverageValue
--distinct Year,count(day)
from [dbo].Mobile
where Pollutant='PM10'
group by pollutant,year,month,day
having (AVG(Value) > 154)
)

select year,count(AverageValue) as NumberOfDays
from PM10
group by year

/********************************************************  Rektorat **********************************************************************/
;with PM10 as
(
select pollutant,year,month,day,AVG(Value) as AverageValue
--distinct Year,count(day)
from [dbo].Rektorat
where Pollutant='PM10'
group by pollutant,year,month,day
having (AVG(Value) > 154)
)

select year,count(AverageValue) as NumberOfDays
from PM10
group by year

-- ## Question 7
-- On how many days in each year, was the value of PM10 measured on at least one location worse than moderate? .......... (3 points)

select Centar,GaziBaba,Karpos,Lisice,Miladinovci,Rektorat,YEAR(time) as Year, month(time) as month, datepart(dd,time) as Day
into #PM10
from AirPollution
where Pollutant='PM10'

select * from #PM10

; with Days as
(
select 
round(AVG(Centar),2) as CentarAverage,
round(AVG(GaziBaba),2) as GaziBabaAverage,
round(AVG(Karpos),2) as KarposAverage,
round(AVG(Lisice),2) as LisiceAverage,
round(AVG(Miladinovci),2) as MiladinovciAverage,
round(AVG(Rektorat),2) as RektoratAverage,
Year,month,day
from #PM10
group by Year,month,Day

)
select 
--*
year, count (*) as NumberOfDays
from Days
where (CentarAverage > 154 or GaziBabaAverage > 154 or KarposAverage >154 or LisiceAverage >154 or MiladinovciAverage >154 or RektoratAverage >154)
group by Year